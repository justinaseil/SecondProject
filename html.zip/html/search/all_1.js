var searchData=
[
  ['egz_0',['egz',['../classStud.html#a0b8f9a231f2bd31cb28af9346229ea80',1,'Stud']]]
];
