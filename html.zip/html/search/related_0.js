var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classStud.html#acdb537f7c2e36b784e639bebfd87da17',1,'Stud']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../classStud.html#a59b3f6366542331cffb2ba230fe5868a',1,'Stud']]]
];
