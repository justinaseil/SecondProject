var searchData=
[
  ['pavarde_0',['pavarde',['../classZmogus.html#a00799e1396c82e4f6dffa0edec1f24e5',1,'Zmogus']]]
];
