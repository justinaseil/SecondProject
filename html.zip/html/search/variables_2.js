var searchData=
[
  ['nd_0',['ND',['../classStud.html#a84ee12eb6e216419205e753089098943',1,'Stud']]]
];
