var searchData=
[
  ['_7estud_0',['~Stud',['../classStud.html#aa1c38d670d1f269ebd48588c40ad58db',1,'Stud']]],
  ['_7ezmogus_1',['~Zmogus',['../classZmogus.html#ac5615bf607a8f2f1b303ffa04328d24d',1,'Zmogus']]]
];
