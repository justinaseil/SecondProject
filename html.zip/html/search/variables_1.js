var searchData=
[
  ['med_0',['med',['../classStud.html#a0b6b9dbd39416e475e7531a224e16e93',1,'Stud']]]
];
