var searchData=
[
  ['rezmed_0',['rezmed',['../classStud.html#abd17299aa6e03f75d56a08dd5c93c427',1,'Stud']]],
  ['rezvid_1',['rezvid',['../classStud.html#ab2dc15e53140a456f94115ea42195366',1,'Stud']]]
];
