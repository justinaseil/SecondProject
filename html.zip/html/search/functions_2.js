var searchData=
[
  ['ived_0',['ived',['../classStud.html#aedc99ae79da5de908870f86fddc55333',1,'Stud']]]
];
