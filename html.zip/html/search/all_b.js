var searchData=
[
  ['testavimas_0',['testavimas',['../stud_8h.html#a7dd5cbd7d364674dcfd69624e8a4ed9a',1,'stud.h']]]
];
