var searchData=
[
  ['val_0',['val',['../classStud.html#ace47ca17836158230e0030f899857b5a',1,'Stud']]],
  ['vidurkis_1',['vidurkis',['../classStud.html#ad6aa875fd30dc021dfff3acc7c924d47',1,'Stud']]]
];
