var searchData=
[
  ['abstraktas_0',['abstraktas',['../classZmogus.html#a13482d5811ff988e8fc8ba7b618add64',1,'Zmogus::abstraktas()'],['../classStud.html#a537b7861db620a9a71f59d2d07e04388',1,'Stud::abstraktas() const override']]],
  ['addnd_1',['addND',['../classStud.html#a5436f4f6c99ae0fe4a0198b65746b595',1,'Stud']]],
  ['autom_2',['autom',['../classStud.html#a36933acc65fbea650eab0f6cf29865a8',1,'Stud']]]
];
