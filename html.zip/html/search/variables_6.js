var searchData=
[
  ['vardas_0',['vardas',['../classZmogus.html#a56da52b45c537a31d2c1fc3a53a73c65',1,'Zmogus']]],
  ['vid_1',['vid',['../classStud.html#adedd35f71aa626e276cbb14d3fe4b1c3',1,'Stud']]]
];
