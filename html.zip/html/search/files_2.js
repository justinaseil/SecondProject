var searchData=
[
  ['stud_2ecpp_0',['stud.cpp',['../stud_8cpp.html',1,'']]],
  ['stud_2eh_1',['stud.h',['../stud_8h.html',1,'']]]
];
