var searchData=
[
  ['sumediana_0',['suMediana',['../classStud.html#a52e8826abe6634d94f00632f33a238ad',1,'Stud']]]
];
